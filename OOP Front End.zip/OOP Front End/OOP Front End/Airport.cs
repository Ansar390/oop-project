﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Front_End.Resources.model
{
    class Airport
    {

        public string airport_name { get; set; }

        public string Country_name { get; set; }

        public string airport_ID { get; set; }

        public string airport_location { get; set; }

    }
}
