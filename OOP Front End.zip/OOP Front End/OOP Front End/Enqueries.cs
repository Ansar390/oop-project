﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Front_End.Resources.model
{
    class Enqueries
    {
        public string enq_id { get; set; }
        public string enq_title { get; set; }
        public string enq_date { get; set; }
        public string enq_type { get; set; }
  

    }
}
