﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Front_End.Resources.model
{
    class ticket
    {
        

        //properties

        public int ticket_id { get; set; }

        public string ticket_type { get; set; }
    
        public int no_of_tickets { get; set; }
        public double payment { get; set; }
     
      
        

        

    
    
    }
}
