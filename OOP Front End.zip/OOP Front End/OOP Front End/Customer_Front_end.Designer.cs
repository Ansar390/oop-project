﻿namespace OOP_Front_End
{
    partial class Customer_Front_end
    {

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelpname = new System.Windows.Forms.Label();
            this.Addbtn = new System.Windows.Forms.Button();
            this.textBoxpname = new System.Windows.Forms.TextBox();
            this.textBoxage = new System.Windows.Forms.TextBox();
            this.labelage = new System.Windows.Forms.Label();
            this.textBoxcnic = new System.Windows.Forms.TextBox();
            this.labelcnic = new System.Windows.Forms.Label();
            this.textBoxaddress = new System.Windows.Forms.TextBox();
            this.labeladdress = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBoxcionfo = new System.Windows.Forms.TextBox();
            this.labelcinfo = new System.Windows.Forms.Label();
            this.labelgender = new System.Windows.Forms.Label();
            this.textBoxemail = new System.Windows.Forms.TextBox();
            this.labelemail = new System.Windows.Forms.Label();
            this.textBoxpassport = new System.Windows.Forms.TextBox();
            this.labelpassport = new System.Windows.Forms.Label();
            this.labelpayment = new System.Windows.Forms.Label();
            this.textBoxpaymebt = new System.Windows.Forms.TextBox();
            this.labelclassticket = new System.Windows.Forms.Label();
            this.labelnoofpassngers = new System.Windows.Forms.Label();
            this.textBoxnoofpassengers = new System.Windows.Forms.TextBox();
            this.labelticketno = new System.Windows.Forms.Label();
            this.textBoxticketno = new System.Windows.Forms.TextBox();
            this.comboboxmalefemale = new System.Windows.Forms.ComboBox();
            this.comboBoxticketclass = new System.Windows.Forms.ComboBox();
            this.textboxluggage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelpname
            // 
            this.labelpname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpname.Location = new System.Drawing.Point(29, 82);
            this.labelpname.Name = "labelpname";
            this.labelpname.Size = new System.Drawing.Size(100, 33);
            this.labelpname.TabIndex = 0;
            this.labelpname.Text = "Name";
            this.labelpname.Click += new System.EventHandler(this.label1_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.Location = new System.Drawing.Point(852, 77);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(94, 40);
            this.Addbtn.TabIndex = 1;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = true;
            this.Addbtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxpname
            // 
            this.textBoxpname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxpname.Location = new System.Drawing.Point(229, 85);
            this.textBoxpname.Name = "textBoxpname";
            this.textBoxpname.Size = new System.Drawing.Size(132, 23);
            this.textBoxpname.TabIndex = 2;
            this.textBoxpname.TextChanged += new System.EventHandler(this.textBoxpname_TextChanged);
            // 
            // textBoxage
            // 
            this.textBoxage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxage.Location = new System.Drawing.Point(229, 213);
            this.textBoxage.Name = "textBoxage";
            this.textBoxage.Size = new System.Drawing.Size(132, 23);
            this.textBoxage.TabIndex = 6;
            this.textBoxage.TextChanged += new System.EventHandler(this.textBoxage_TextChanged);
            // 
            // labelage
            // 
            this.labelage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelage.Location = new System.Drawing.Point(29, 200);
            this.labelage.Name = "labelage";
            this.labelage.Size = new System.Drawing.Size(100, 33);
            this.labelage.TabIndex = 5;
            this.labelage.Text = "Age";
            // 
            // textBoxcnic
            // 
            this.textBoxcnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxcnic.Location = new System.Drawing.Point(229, 172);
            this.textBoxcnic.Name = "textBoxcnic";
            this.textBoxcnic.Size = new System.Drawing.Size(132, 23);
            this.textBoxcnic.TabIndex = 8;
            this.textBoxcnic.TextChanged += new System.EventHandler(this.textBoxcnic_TextChanged);
            // 
            // labelcnic
            // 
            this.labelcnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcnic.Location = new System.Drawing.Point(29, 167);
            this.labelcnic.Name = "labelcnic";
            this.labelcnic.Size = new System.Drawing.Size(100, 33);
            this.labelcnic.TabIndex = 7;
            this.labelcnic.Text = "CNIC";
            // 
            // textBoxaddress
            // 
            this.textBoxaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxaddress.Location = new System.Drawing.Point(229, 128);
            this.textBoxaddress.Name = "textBoxaddress";
            this.textBoxaddress.Size = new System.Drawing.Size(132, 23);
            this.textBoxaddress.TabIndex = 10;
            this.textBoxaddress.TextChanged += new System.EventHandler(this.textBoxaddress_TextChanged);
            // 
            // labeladdress
            // 
            this.labeladdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeladdress.Location = new System.Drawing.Point(29, 125);
            this.labeladdress.Name = "labeladdress";
            this.labeladdress.Size = new System.Drawing.Size(120, 33);
            this.labeladdress.TabIndex = 9;
            this.labeladdress.Text = "Address";
            this.labeladdress.Click += new System.EventHandler(this.labeladdress_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(852, 159);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 40);
            this.button2.TabIndex = 11;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(852, 241);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 40);
            this.button3.TabIndex = 12;
            this.button3.Text = "Update";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBoxcionfo
            // 
            this.textBoxcionfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxcionfo.Location = new System.Drawing.Point(229, 256);
            this.textBoxcionfo.Name = "textBoxcionfo";
            this.textBoxcionfo.Size = new System.Drawing.Size(132, 23);
            this.textBoxcionfo.TabIndex = 15;
            this.textBoxcionfo.TextChanged += new System.EventHandler(this.textBoxcionfo_TextChanged);
            // 
            // labelcinfo
            // 
            this.labelcinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcinfo.Location = new System.Drawing.Point(29, 246);
            this.labelcinfo.Name = "labelcinfo";
            this.labelcinfo.Size = new System.Drawing.Size(167, 33);
            this.labelcinfo.TabIndex = 14;
            this.labelcinfo.Text = "Contact Info";
            // 
            // labelgender
            // 
            this.labelgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelgender.Location = new System.Drawing.Point(29, 297);
            this.labelgender.Name = "labelgender";
            this.labelgender.Size = new System.Drawing.Size(120, 33);
            this.labelgender.TabIndex = 16;
            this.labelgender.Text = "Gender";
            // 
            // textBoxemail
            // 
            this.textBoxemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxemail.Location = new System.Drawing.Point(609, 266);
            this.textBoxemail.Name = "textBoxemail";
            this.textBoxemail.Size = new System.Drawing.Size(135, 23);
            this.textBoxemail.TabIndex = 19;
            this.textBoxemail.TextChanged += new System.EventHandler(this.textBoxemail_TextChanged);
            // 
            // labelemail
            // 
            this.labelemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelemail.Location = new System.Drawing.Point(398, 256);
            this.labelemail.Name = "labelemail";
            this.labelemail.Size = new System.Drawing.Size(120, 33);
            this.labelemail.TabIndex = 18;
            this.labelemail.Text = "Email";
            // 
            // textBoxpassport
            // 
            this.textBoxpassport.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxpassport.Location = new System.Drawing.Point(609, 216);
            this.textBoxpassport.Name = "textBoxpassport";
            this.textBoxpassport.Size = new System.Drawing.Size(135, 23);
            this.textBoxpassport.TabIndex = 21;
            this.textBoxpassport.TextChanged += new System.EventHandler(this.textBoxpassport_TextChanged);
            // 
            // labelpassport
            // 
            this.labelpassport.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpassport.Location = new System.Drawing.Point(398, 213);
            this.labelpassport.Name = "labelpassport";
            this.labelpassport.Size = new System.Drawing.Size(120, 33);
            this.labelpassport.TabIndex = 20;
            this.labelpassport.Text = "Passport No";
            this.labelpassport.Click += new System.EventHandler(this.labelpassport_Click);
            // 
            // labelpayment
            // 
            this.labelpayment.AutoSize = true;
            this.labelpayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpayment.Location = new System.Drawing.Point(398, 176);
            this.labelpayment.Name = "labelpayment";
            this.labelpayment.Size = new System.Drawing.Size(83, 24);
            this.labelpayment.TabIndex = 31;
            this.labelpayment.Text = "Payment";
            this.labelpayment.Click += new System.EventHandler(this.labelpayment_Click);
            // 
            // textBoxpaymebt
            // 
            this.textBoxpaymebt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxpaymebt.Location = new System.Drawing.Point(609, 179);
            this.textBoxpaymebt.Name = "textBoxpaymebt";
            this.textBoxpaymebt.Size = new System.Drawing.Size(135, 23);
            this.textBoxpaymebt.TabIndex = 30;
            this.textBoxpaymebt.TextChanged += new System.EventHandler(this.textBoxpaymebt_TextChanged);
            // 
            // labelclassticket
            // 
            this.labelclassticket.AutoSize = true;
            this.labelclassticket.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelclassticket.Location = new System.Drawing.Point(29, 356);
            this.labelclassticket.Name = "labelclassticket";
            this.labelclassticket.Size = new System.Drawing.Size(110, 24);
            this.labelclassticket.TabIndex = 26;
            this.labelclassticket.Text = "Ticket Class";
            // 
            // labelnoofpassngers
            // 
            this.labelnoofpassngers.AutoSize = true;
            this.labelnoofpassngers.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnoofpassngers.Location = new System.Drawing.Point(398, 128);
            this.labelnoofpassngers.Name = "labelnoofpassngers";
            this.labelnoofpassngers.Size = new System.Drawing.Size(159, 24);
            this.labelnoofpassngers.TabIndex = 25;
            this.labelnoofpassngers.Text = "No of Passengers";
            // 
            // textBoxnoofpassengers
            // 
            this.textBoxnoofpassengers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxnoofpassengers.Location = new System.Drawing.Point(609, 131);
            this.textBoxnoofpassengers.Name = "textBoxnoofpassengers";
            this.textBoxnoofpassengers.Size = new System.Drawing.Size(135, 23);
            this.textBoxnoofpassengers.TabIndex = 24;
            this.textBoxnoofpassengers.TextChanged += new System.EventHandler(this.textBoxnoofpassengers_TextChanged);
            // 
            // labelticketno
            // 
            this.labelticketno.AutoSize = true;
            this.labelticketno.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelticketno.Location = new System.Drawing.Point(398, 85);
            this.labelticketno.Name = "labelticketno";
            this.labelticketno.Size = new System.Drawing.Size(90, 24);
            this.labelticketno.TabIndex = 23;
            this.labelticketno.Text = "Ticket No";
            // 
            // textBoxticketno
            // 
            this.textBoxticketno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxticketno.Location = new System.Drawing.Point(609, 85);
            this.textBoxticketno.Name = "textBoxticketno";
            this.textBoxticketno.Size = new System.Drawing.Size(135, 23);
            this.textBoxticketno.TabIndex = 22;
            this.textBoxticketno.TextChanged += new System.EventHandler(this.textBoxticketno_TextChanged);
            // 
            // comboboxmalefemale
            // 
            this.comboboxmalefemale.FormattingEnabled = true;
            this.comboboxmalefemale.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.comboboxmalefemale.Location = new System.Drawing.Point(229, 302);
            this.comboboxmalefemale.Name = "comboboxmalefemale";
            this.comboboxmalefemale.Size = new System.Drawing.Size(132, 21);
            this.comboboxmalefemale.TabIndex = 32;
            this.comboboxmalefemale.SelectedIndexChanged += new System.EventHandler(this.comboboxmalefemale_SelectedIndexChanged);
            // 
            // comboBoxticketclass
            // 
            this.comboBoxticketclass.FormattingEnabled = true;
            this.comboBoxticketclass.Items.AddRange(new object[] {
            "Economy Class",
            "Bussiness Class"});
            this.comboBoxticketclass.Location = new System.Drawing.Point(229, 361);
            this.comboBoxticketclass.Name = "comboBoxticketclass";
            this.comboBoxticketclass.Size = new System.Drawing.Size(132, 21);
            this.comboBoxticketclass.TabIndex = 33;
            this.comboBoxticketclass.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textboxluggage
            // 
            this.textboxluggage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxluggage.Location = new System.Drawing.Point(609, 307);
            this.textboxluggage.Name = "textboxluggage";
            this.textboxluggage.Size = new System.Drawing.Size(135, 23);
            this.textboxluggage.TabIndex = 35;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(398, 297);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 33);
            this.label1.TabIndex = 34;
            this.label1.Text = "Luggage Carried";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(852, 326);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 40);
            this.button1.TabIndex = 36;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Customer_Front_end
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1102, 475);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textboxluggage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxticketclass);
            this.Controls.Add(this.comboboxmalefemale);
            this.Controls.Add(this.labelpayment);
            this.Controls.Add(this.textBoxpaymebt);
            this.Controls.Add(this.labelclassticket);
            this.Controls.Add(this.labelnoofpassngers);
            this.Controls.Add(this.textBoxnoofpassengers);
            this.Controls.Add(this.labelticketno);
            this.Controls.Add(this.textBoxticketno);
            this.Controls.Add(this.textBoxpassport);
            this.Controls.Add(this.labelpassport);
            this.Controls.Add(this.textBoxemail);
            this.Controls.Add(this.labelemail);
            this.Controls.Add(this.labelgender);
            this.Controls.Add(this.textBoxcionfo);
            this.Controls.Add(this.labelcinfo);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBoxaddress);
            this.Controls.Add(this.labeladdress);
            this.Controls.Add(this.textBoxcnic);
            this.Controls.Add(this.labelcnic);
            this.Controls.Add(this.textBoxage);
            this.Controls.Add(this.labelage);
            this.Controls.Add(this.textBoxpname);
            this.Controls.Add(this.Addbtn);
            this.Controls.Add(this.labelpname);
            this.Name = "Customer_Front_end";
            this.Text = "Customer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelpname;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Label labelage;
        private System.Windows.Forms.Label labelcnic;
        private System.Windows.Forms.Label labeladdress;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label labelcinfo;
        private System.Windows.Forms.Label labelgender;
        private System.Windows.Forms.Label labelemail;
        private System.Windows.Forms.Label labelpassport;
        private System.Windows.Forms.Label labelpayment;
        private System.Windows.Forms.Label labelclassticket;
        private System.Windows.Forms.Label labelnoofpassngers;
        private System.Windows.Forms.Label labelticketno;
        private System.Windows.Forms.ComboBox comboBoxticketclass;
        public System.Windows.Forms.TextBox textBoxpname;
        public System.Windows.Forms.TextBox textBoxage;
        public System.Windows.Forms.TextBox textBoxcnic;
        public System.Windows.Forms.TextBox textBoxaddress;
        public System.Windows.Forms.TextBox textBoxcionfo;
        public System.Windows.Forms.TextBox textBoxemail;
        public System.Windows.Forms.TextBox textBoxpassport;
        public System.Windows.Forms.TextBox textBoxpaymebt;
        public System.Windows.Forms.TextBox textBoxnoofpassengers;
        public System.Windows.Forms.TextBox textBoxticketno;
        public System.Windows.Forms.ComboBox comboboxmalefemale;
        public System.Windows.Forms.TextBox textboxluggage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}