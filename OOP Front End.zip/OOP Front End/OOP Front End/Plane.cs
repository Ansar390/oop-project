﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Front_End.Resources.model
{
    class Plane
    {
        public string plane_name { get; set; }
        public string plane_code { get; set; }
        public int plane_capacity { get; set; }

        public string plane_model { get; set; }

    }
}
