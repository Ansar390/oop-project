﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Front_End.Resources.model
{
    class Admin
    {
        public string admin_Password { get; set; }  

        //functions
        public void Login()
        {

        }
        public void Logout()
        {

        }
    }
}
