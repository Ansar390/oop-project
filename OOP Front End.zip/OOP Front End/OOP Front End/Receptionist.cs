﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Front_End.Resources.model
{
    class Receptionist:Person
    {
        public string Rec_Password { get; set; }  
    }
}
