﻿namespace OOP_Front_End
{
    partial class AdminRes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.flightSchdleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addFlightToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.routeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addRouteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cabinAttendentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCabinAttendentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.queriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addQueryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.airportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addAirportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recepetionistToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addPilotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pilotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addPilotToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.activityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.performActivityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.flightSchdleToolStripMenuItem,
            this.routeToolStripMenuItem,
            this.cabinAttendentToolStripMenuItem,
            this.queriesToolStripMenuItem,
            this.airportToolStripMenuItem,
            this.recepetionistToolStripMenuItem,
            this.pilotToolStripMenuItem,
            this.activityToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1025, 24);
            this.menuStrip1.TabIndex = 53;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // flightSchdleToolStripMenuItem
            // 
            this.flightSchdleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addFlightToolStripMenuItem1});
            this.flightSchdleToolStripMenuItem.Name = "flightSchdleToolStripMenuItem";
            this.flightSchdleToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.flightSchdleToolStripMenuItem.Text = "Flight Schdlue";
            this.flightSchdleToolStripMenuItem.Click += new System.EventHandler(this.flightSchdleToolStripMenuItem_Click);
            // 
            // addFlightToolStripMenuItem1
            // 
            this.addFlightToolStripMenuItem1.Name = "addFlightToolStripMenuItem1";
            this.addFlightToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.addFlightToolStripMenuItem1.Text = "Manage Flight";
            this.addFlightToolStripMenuItem1.Click += new System.EventHandler(this.addFlightToolStripMenuItem1_Click);
            // 
            // routeToolStripMenuItem
            // 
            this.routeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addRouteToolStripMenuItem});
            this.routeToolStripMenuItem.Name = "routeToolStripMenuItem";
            this.routeToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.routeToolStripMenuItem.Text = "Route";
            this.routeToolStripMenuItem.Click += new System.EventHandler(this.routeToolStripMenuItem_Click);
            // 
            // addRouteToolStripMenuItem
            // 
            this.addRouteToolStripMenuItem.Name = "addRouteToolStripMenuItem";
            this.addRouteToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.addRouteToolStripMenuItem.Text = "Manage Route";
            this.addRouteToolStripMenuItem.Click += new System.EventHandler(this.addRouteToolStripMenuItem_Click);
            // 
            // cabinAttendentToolStripMenuItem
            // 
            this.cabinAttendentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCabinAttendentToolStripMenuItem});
            this.cabinAttendentToolStripMenuItem.Name = "cabinAttendentToolStripMenuItem";
            this.cabinAttendentToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.cabinAttendentToolStripMenuItem.Text = "Cabin Attendent";
            this.cabinAttendentToolStripMenuItem.Click += new System.EventHandler(this.cabinAttendentToolStripMenuItem_Click);
            // 
            // addCabinAttendentToolStripMenuItem
            // 
            this.addCabinAttendentToolStripMenuItem.Name = "addCabinAttendentToolStripMenuItem";
            this.addCabinAttendentToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.addCabinAttendentToolStripMenuItem.Text = "Manage Cabin Attendent";
            this.addCabinAttendentToolStripMenuItem.Click += new System.EventHandler(this.addCabinAttendentToolStripMenuItem_Click);
            // 
            // queriesToolStripMenuItem
            // 
            this.queriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addQueryToolStripMenuItem});
            this.queriesToolStripMenuItem.Name = "queriesToolStripMenuItem";
            this.queriesToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.queriesToolStripMenuItem.Text = "Queries";
            this.queriesToolStripMenuItem.Click += new System.EventHandler(this.queriesToolStripMenuItem_Click);
            // 
            // addQueryToolStripMenuItem
            // 
            this.addQueryToolStripMenuItem.Name = "addQueryToolStripMenuItem";
            this.addQueryToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.addQueryToolStripMenuItem.Text = "Manage Query";
            this.addQueryToolStripMenuItem.Click += new System.EventHandler(this.addQueryToolStripMenuItem_Click);
            // 
            // airportToolStripMenuItem
            // 
            this.airportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addAirportToolStripMenuItem});
            this.airportToolStripMenuItem.Name = "airportToolStripMenuItem";
            this.airportToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.airportToolStripMenuItem.Text = "Airport";
            // 
            // addAirportToolStripMenuItem
            // 
            this.addAirportToolStripMenuItem.Name = "addAirportToolStripMenuItem";
            this.addAirportToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.addAirportToolStripMenuItem.Text = "Manage Airport";
            this.addAirportToolStripMenuItem.Click += new System.EventHandler(this.addAirportToolStripMenuItem_Click);
            // 
            // recepetionistToolStripMenuItem
            // 
            this.recepetionistToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addPilotToolStripMenuItem});
            this.recepetionistToolStripMenuItem.Name = "recepetionistToolStripMenuItem";
            this.recepetionistToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.recepetionistToolStripMenuItem.Text = "Recepetionist";
            // 
            // addPilotToolStripMenuItem
            // 
            this.addPilotToolStripMenuItem.Name = "addPilotToolStripMenuItem";
            this.addPilotToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.addPilotToolStripMenuItem.Text = "Manage Pilot";
            this.addPilotToolStripMenuItem.Click += new System.EventHandler(this.addPilotToolStripMenuItem_Click);
            // 
            // pilotToolStripMenuItem
            // 
            this.pilotToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addPilotToolStripMenuItem1});
            this.pilotToolStripMenuItem.Name = "pilotToolStripMenuItem";
            this.pilotToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.pilotToolStripMenuItem.Text = "Pilot";
            // 
            // addPilotToolStripMenuItem1
            // 
            this.addPilotToolStripMenuItem1.Name = "addPilotToolStripMenuItem1";
            this.addPilotToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.addPilotToolStripMenuItem1.Text = "Manage Pilot";
            this.addPilotToolStripMenuItem1.Click += new System.EventHandler(this.addPilotToolStripMenuItem1_Click);
            // 
            // activityToolStripMenuItem
            // 
            this.activityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.performActivityToolStripMenuItem});
            this.activityToolStripMenuItem.Name = "activityToolStripMenuItem";
            this.activityToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.activityToolStripMenuItem.Text = "Activity";
            this.activityToolStripMenuItem.Click += new System.EventHandler(this.activityToolStripMenuItem_Click);
            // 
            // performActivityToolStripMenuItem
            // 
            this.performActivityToolStripMenuItem.Name = "performActivityToolStripMenuItem";
            this.performActivityToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.performActivityToolStripMenuItem.Text = "Perform Activity";
            this.performActivityToolStripMenuItem.Click += new System.EventHandler(this.performActivityToolStripMenuItem_Click);
            // 
            // AdminRes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1025, 349);
            this.Controls.Add(this.menuStrip1);
            this.Name = "AdminRes";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.AdminRes_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem flightSchdleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem routeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addRouteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cabinAttendentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCabinAttendentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem queriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addQueryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addFlightToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem airportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addAirportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recepetionistToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addPilotToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pilotToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addPilotToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem activityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem performActivityToolStripMenuItem;
    }
}