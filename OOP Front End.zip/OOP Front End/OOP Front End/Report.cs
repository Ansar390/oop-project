﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Front_End.Resources.model
{
    class Report
    {
        public int _Report_total_passenger { get; set; }
        public double Report_total_earning { get; set; }
        //functions
        public void daily_report()
        {

        }
        public void weekly_report()
        {

        }
        public void monthly_report()
        {

        } 
    }
}
